package com.emirgulcur.restclientprojectv2.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.emirgulcur.restclientprojectv2.R;
import com.emirgulcur.restclientprojectv2.adapter.RecyclerViewAdapter;
import com.emirgulcur.restclientprojectv2.model.Repository;
import com.emirgulcur.restclientprojectv2.service.ClientAPI;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
ArrayList<Repository> repositories;
private String BASE_URL="https://github-trending-api.now.sh/";
Retrofit retrofit;
RecyclerView recyclerView;
RecyclerViewAdapter recyclerViewAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      //  "https://github-trending-api.now.sh/repositories"

    //Retrofit & JSON
        recyclerView=findViewById(R.id.recyclerView);




        Gson gson=new GsonBuilder().setLenient().create();

        retrofit=new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create(gson)).build();
        loadData();
    }
    private void loadData(){
        ClientAPI clientAPI=retrofit.create(ClientAPI.class);
        Call<List<Repository>> call=clientAPI.getData();
        call.enqueue(new Callback<List<Repository>>() {
            @Override
            public void onResponse(Call<List<Repository>> call, Response<List<Repository>> response) {
                if(response.isSuccessful()){
                    List<Repository> responseList=response.body();
                    repositories=new ArrayList<>(responseList);

                    //RecyclerView
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    recyclerViewAdapter=new RecyclerViewAdapter(repositories);
                    recyclerView.setAdapter(recyclerViewAdapter);

/*

                    for(Repository repositories:repositories){
                        System.out.println(repositories.author);
                        System.out.println(repositories.url);
                        System.out.println(repositories.description);
                        System.out.println(repositories.language);
                        System.out.println(repositories.title);
                        System.out.println(repositories.forks);
                        System.out.println(repositories.stars);
                        System.out.println(repositories.currentPeriodStars);

                    }
*/
                }
            }

            @Override
            public void onFailure(Call<List<Repository>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

}