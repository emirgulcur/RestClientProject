package com.emirgulcur.restclientprojectv2.service;

import com.emirgulcur.restclientprojectv2.model.Repository;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ClientAPI {
    @GET("repositories")

    //https://github-trending-api.now.sh/repositories
    Call<List<Repository>> getData();
}
