package com.emirgulcur.restclientprojectv2.model;
import com.google.gson.annotations.SerializedName;

public class Repository {
    @SerializedName("title")
    public String title;
    @SerializedName("author")
    public String author;
    @SerializedName("url")
    public String url;
    @SerializedName("description")
    public String description;
    @SerializedName("language")
    public String language;
    @SerializedName("stars")
    public int stars;
    @SerializedName("forks")
    public int forks;
    @SerializedName("currentPeriodStars")
    public int currentPeriodStars;









}

