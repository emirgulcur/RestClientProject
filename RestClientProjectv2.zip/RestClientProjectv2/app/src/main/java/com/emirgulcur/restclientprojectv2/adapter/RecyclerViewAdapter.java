package com.emirgulcur.restclientprojectv2.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.emirgulcur.restclientprojectv2.R;
import com.emirgulcur.restclientprojectv2.model.Repository;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RowHolder> {
    private ArrayList<Repository> repolist;
    private String[] colors={"#ff6700","#8e0000","#8ee5ee","#ffffe5"};

    public RecyclerViewAdapter(ArrayList<Repository> repolist ){
        this.repolist=repolist;
    }

    @NonNull
    @Override
    public RowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View view=layoutInflater.inflate(R.layout.row_layout,parent,false);
        return new RowHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RowHolder holder, int position) {
        holder.bind(repolist.get(position),colors,position);
    }

    @Override
    public int getItemCount() {
        return repolist.size();
    }

    public class RowHolder extends RecyclerView.ViewHolder {
            TextView title;
            TextView repo;
            TextView stars;


        public RowHolder(@NonNull View itemView) {
            super(itemView);

            title=itemView.findViewById(R.id.text_title);
            repo=itemView.findViewById(R.id.text_repo);
            stars=itemView.findViewById(R.id.text_stars);
        }

        public void bind(Repository repository,String[] colors,Integer position){
            itemView.setBackgroundColor(Color.parseColor(colors[position % 4]));
            title=itemView.findViewById(R.id.text_title);
            stars=itemView.findViewById(R.id.text_stars);
            repo=itemView.findViewById(R.id.text_repo);
            title.setText(repository.title);
            repo.setText(repository.author);
            stars.setText(repository.stars);


        }
    }
}
